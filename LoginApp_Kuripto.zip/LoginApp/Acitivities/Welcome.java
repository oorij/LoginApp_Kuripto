package bsu.bsit3d.login2;

import static bsu.bsit3d.login2.LogIn.accNumber;
import static bsu.bsit3d.login2.LogIn.emailList;
import static bsu.bsit3d.login2.LogIn.passList;
import static bsu.bsit3d.login2.LogIn.userList;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Welcome extends AppCompatActivity {

    TextView txtUsername, txtPassword, txtEmail;
    Button btnEdit, btnDelete, btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);

        String username = LogIn.getusername();
        txtUsername = findViewById(R.id.txtUsername);
        txtUsername.setText("Username: " + username);
        String email = LogIn.getemail();
        txtEmail = findViewById(R.id.txtEmail);
        txtEmail.setText("Email: " + email);
        String password = LogIn.getpassword();
        txtPassword = findViewById(R.id.txtPassword);
        txtPassword.setText("Password: " + password);

        btnEdit = findViewById(R.id.btnEdit);
        btnDelete = findViewById(R.id.btnDelete);
        btnLogout = findViewById(R.id.btnLogout);

        btnEdit.setOnClickListener(v -> Edit());
        btnDelete.setOnClickListener(v -> Delete());
        btnLogout.setOnClickListener(v -> showLogout());
    }

    public void LogIn() {
        Intent intent = new Intent(this, LogIn.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }
    public void Edit() {
        Intent intent = new Intent(this, Edit.class);
        startActivity(intent);
    }
    private void showLogout() {
        AlertDialog.Builder alert = new AlertDialog.Builder(Welcome.this);
        alert.setMessage("Are you sure?")
                .setPositiveButton("Logout", new DialogInterface.OnClickListener()                 {
                    public void onClick(DialogInterface dialog, int which) {
                        LogIn();
                    }
                }).setNegativeButton("Cancel", null);
        AlertDialog alert1 = alert.create();
        alert1.show();
    }
    public void Delete(){
        AlertDialog.Builder alert = new AlertDialog.Builder(Welcome.this);
        alert.setMessage("Are you sure you want to delete this account?")
                .setPositiveButton("Delete", new DialogInterface.OnClickListener()                 {
                    public void onClick(DialogInterface dialog, int which) {
                        userList.remove(accNumber);
                        passList.remove(accNumber);
                        emailList.remove(accNumber);
                        LogIn();
                    }
                }).setNegativeButton("Cancel", null);
        AlertDialog alert1 = alert.create();
        alert1.show();
    }
    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        showLogout();
    }
}