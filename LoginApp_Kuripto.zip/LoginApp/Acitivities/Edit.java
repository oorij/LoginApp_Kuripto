package bsu.bsit3d.login2;

import static bsu.bsit3d.login2.LogIn.*;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Edit extends AppCompatActivity {

    TextView invalid;
    EditText txtuser, txtemail,txtcurrentpass, txtnewpass, txtconfirmnewpass;
    Button done, cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit);

        txtuser = findViewById(R.id.txtUsername);
        txtemail = findViewById(R.id.txtEmail);
        txtcurrentpass = findViewById(R.id.txtCurrentpassword);
        txtnewpass = findViewById(R.id.txtNewpassword);
        txtconfirmnewpass = findViewById(R.id.txtConfirmnewpassword);
        done = findViewById(R.id.btnDone);
        cancel = findViewById(R.id.btnCancel);
        invalid = findViewById(R.id.txtInvalid);
        txtuser.setText(logged_username);
        txtemail.setText(logged_email);

        done.setOnClickListener(v -> editAccount());
        cancel.setOnClickListener(v -> Welcome());
    }
    public void editAccount() {
        String user = txtuser.getText().toString();
        String email = txtemail.getText().toString();
        String newpass = txtnewpass.getText().toString();
        String confirmnewpass = txtconfirmnewpass.getText().toString();
        String currentpass = txtcurrentpass.getText().toString();
        boolean verified = false;

        if (currentpass.isEmpty() || newpass.isEmpty() || confirmnewpass.isEmpty()) {
            invalid.setText("Please fill-up all of the password fields.");
        } else if (!currentpass.equals(logged_password)) {
            invalid.setText("Wrong Password.");
        } else if (!newpass.equals(confirmnewpass)) {
            invalid.setText("Passwords do not match.");
        } else {
            if (!user.isEmpty() || !email.isEmpty()) {
                if (!email.equals(logged_email) && emailList.contains(email)) {
                    invalid.setText("An account is already registered with the given email.");
                    return;
                }
                if (!user.equals(logged_username) && userList.contains(user)) {
                    invalid.setText("Username is already taken.");
                    return;
                }
                userList.set(accNumber, user);
                emailList.set(accNumber, email);
                logged_username = user;
                logged_email = email;
            }
            passList.set(accNumber, newpass);
            logged_password = newpass;
            verified = true;
        }

        if (verified) {
            Welcome();
        }
    }

    public void Welcome() {
        Intent intent = new Intent(this, Welcome.class);
        startActivity(intent);
    }
}