package bsu.bsit3d.login2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

public class LogIn extends AppCompatActivity {

    EditText txtuser, txtpass;
    Button login;
    TextView signup, invalid;

    static String logged_username, logged_password, logged_email;
    static int accNumber;
    String user, pass;
    boolean userfound;
    static ArrayList<String> userList = new ArrayList<>();
    static ArrayList<String> passList = new ArrayList<>();
    static ArrayList<String> emailList = new ArrayList<>();
    //Pre-defined Accounts

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        txtuser = findViewById(R.id.txtUsername);
        txtpass = findViewById(R.id.txtPassword);
        login = findViewById(R.id.btnLogin);
        signup = findViewById(R.id.txtSignup);
        invalid = findViewById(R.id.txtInvalid);

        login.setOnClickListener(v -> LogInAccount());
        signup.setOnClickListener(v -> SignUp());
    }

    public void LogInAccount(){
        user = txtuser.getText().toString();
        pass = txtpass.getText().toString();
        if (user.isEmpty() || pass.isEmpty()) {
            invalid.setText("Please enter both username and password.");
            return;
        }
        for (int i = 0; i<userList.size(); i++) {
            if (userList.get(i).equals(user) || emailList.get(i).equals(user)) {
                if (passList.get(i).equals(pass)) {
                    String username = userList.get(i);
                    String password = passList.get(i);
                    String email = emailList.get(i);
                    setusername(username);
                    setemail(email);
                    setpassword(password);
                    userfound = true;
                    invalid.setText("");
                    accNumber = i ;
                    Welcome();
                } else {
                    invalid.setText("Username or password is incorrect.");
                    break;
                }
            }
        }
        if (!userfound){
            invalid.setText("Username or password is incorrect.");
            userfound = false;
        }
    }
    public void Welcome() {
        Intent intent = new Intent(this, Welcome.class);
        startActivity(intent);
    }
    public void SignUp() {
        Intent intent = new Intent(this, SignUp.class);
        startActivity(intent);
    }
    public static String getusername(){
        return logged_username;
    }
    public void setusername(String username){
        this.logged_username = username;
    }
    public static String getpassword(){
        return logged_password;
    }
    public void setpassword(String password){
        this.logged_password = password;
    }
    public static String getemail(){
        return logged_email;
    }
    public void setemail(String email){
        this.logged_email = email;
    }
}