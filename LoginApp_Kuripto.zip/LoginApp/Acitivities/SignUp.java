package bsu.bsit3d.login2;

import static bsu.bsit3d.login2.LogIn.emailList;
import static bsu.bsit3d.login2.LogIn.passList;
import static bsu.bsit3d.login2.LogIn.userList;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SignUp extends AppCompatActivity {

    TextView invalid, login;
    EditText txtuser, txtemail, txtpass, txtconfirmpass;
    Button signup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);

        txtuser = findViewById(R.id.txtUsername);
        txtemail = findViewById(R.id.txtEmail);
        txtpass = findViewById(R.id.txtPassword);
        txtconfirmpass = findViewById(R.id.txtConfirmpassword);
        signup = findViewById(R.id.btnSignup);
        login = findViewById(R.id.txtLogin);
        invalid = findViewById(R.id.txtInvalid);

        signup.setOnClickListener(v -> SignUpAccount());
        login.setOnClickListener(v -> finish());
    }
    public void SignUpAccount() {
        String user = txtuser.getText().toString();
        String email = txtemail.getText().toString();
        String pass = txtpass.getText().toString();
        String confirmpass = txtconfirmpass.getText().toString();
        boolean verified = true; // Default to true until any condition fails

        if (user.isEmpty() || pass.isEmpty() || email.isEmpty() || confirmpass.isEmpty()) {
            invalid.setText("Please fill-up all of the information.");
            verified = false;
        } else if (!pass.equals(confirmpass)) {
            invalid.setText("Password does not match.");
            verified = false;
        } else if (emailList.contains(email)) {
            invalid.setText("An account is already registered with the given email.");
            verified = false;
        } else if (userList.contains(user)) {
            invalid.setText("Username is already taken.");
            verified = false;
        }

        if (verified){
            userList.add(user);
            passList.add(pass);
            emailList.add(email);
            finish();
        }
    }
}